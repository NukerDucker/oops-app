from flask import Flask, request, jsonify, session
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS
from modules.user import User
from modules.task import Task

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Allow frontend to communicate with backend

# JWT configuration
app.config['JWT_SECRET_KEY'] = 'your_secret_key_here'  # Change this in production

# Initialize extensions
bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# In-memory user storage
users = []

# Add default admin user
hashed_password = bcrypt.generate_password_hash("password").decode('utf-8')
admin_user = User(1, "Admin", hashed_password, "admin")
admin_user.add_access_permission("Inventory", "/inventory")
admin_user.add_access_permission("Patient", "/patient")
admin_user.add_access_permission("Main", "/main")
users.append(admin_user)

# Add tasks
admin_user.add_task(Task(1, "Task 1", "This is task 1"))
admin_user.add_task(Task(2, "Task 2", "This is task 2"))
admin_user.add_task(Task(3, "Task 3", "This is task 3"))

# Add weekly tasks
admin_user.add_weekly_task(Task(1, "Weekly Task 1", "This is weekly task 1"))
admin_user.add_weekly_task(Task(2, "Weekly Task 2", "This is weekly task 2"))

# Add emergency task
admin_user.add_emergency_task(Task(1, "Emergency Task 1", "This is emergency task 1"))
users.append(admin_user)

doctor1_user = User(2, "Doctor1", hashed_password, "doctor")
doctor1_user.add_access_permission("Patient", "/patient")
doctor1_user.add_access_permission("Main", "/main")
users.append(doctor1_user)

doctor1_user.add_task(Task(1, "Follow-Up", "Mr. Napaul HIV checkup"))
doctor1_user.add_task(Task(2, "Prescribe", "Mr. Bento paracetamol prescription"))

doctor1_user.add_weekly_task(Task(1, "Seminar @BKK", "Trans people seminar"))

doctor2_user = User(3, "Doctor2", hashed_password, "doctor")
doctor2_user.add_access_permission("Patient", "/patient")
doctor2_user.add_access_permission("Main", "/main")
users.append(doctor2_user)

doctor2_user.add_task(Task(1, "Follow-Up", "Mr. Sandwich toothache checkup"))
doctor2_user.add_emergency_task(Task(1, "Euthanization", "Smoke you know who"))



# Helper function to find user by username
def find_user_by_username(username):
    for user in users:
        if user.username == username:
            return user
    return None

# Register Route
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400
        
    if find_user_by_username(username):
        return jsonify({"error": "Username already taken"}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    user_id = len(users) + 1  # Simple ID generation
    new_user = User(user_id, username, hashed_password)
    users.append(new_user)

    return jsonify({"message": "User registered successfully"}), 201

# Login Route
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    user = find_user_by_username(username)
    if not user or not bcrypt.check_password_hash(user.password_hash, password):
        print("Invalid username or password")
        return jsonify({"error": "Invalid username or password"}), 401

    # Create JWT token - store just the username as identity
    access_token = create_access_token(identity=user.username)
    print(f"User {user.username} logged in")
    return jsonify({"access_token": access_token, "user": user.to_dict()}), 200

# Protected Route
@app.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    current_username = get_jwt_identity()
    return jsonify({"message": f"Hello, {current_username}! This is a protected route."}), 200

@app.route('/api/user-data', methods=['GET'])
@jwt_required()
def get_user_data():
    current_username = get_jwt_identity()  # This is now just the username string
    user = find_user_by_username(current_username)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify(user.to_dict())

@app.route('/api/users', methods=['GET'])
@jwt_required()
def get_all_users():
    # Only allow admin to see all users
    current_username = get_jwt_identity()  # This is now just the username string
    user = find_user_by_username(current_username)
    
    if user.user_type != "admin":
        return jsonify({'error': 'Unauthorized'}), 403
    
    return jsonify([u.to_dict() for u in users])

if __name__ == '__main__':
    app.run(debug=True)
